  /*
  JS file for selection .
  */

  $(function () {

  // variable declared for styling of the cinema seats.
  var settings = {
    rows: 5, //total no of rows in cinema hall.
    cols: 15, //total no of columns in cinema hall.
    rowCssPrefix: 'row-', // prefix for row used in CSS.
    colCssPrefix: 'col-', // prefix for row used in CSS.
    seatWidth: 45, //Width of the seat.
    seatHeight: 65,//height of the seat.
    seatCss: 'seat', //id for seat.
    selectedSeatCss: 'selectedSeat', //mapping seat to respective CSS id.
    selectingSeatCss: 'selectingSeat', //mapping seat to respective CSS id.
    availableSeatCss : 'availableSeat' //mapping seat to respective CSS id. 
  };

  var init = function (reservedSeat,silverSeats,goldSeats) {
    var str = [], seatNo, className; // initilalize of variable.
    var count = 0; // count => for putting seat No.
    // Loop for putting seats into the container row wise.
    for (i = 0; i < settings.rows; i++) {
      for (j = 0; j < settings.cols; j++) {
        seatNo = ++count;   //setting of seatNo.
        className = settings.seatCss + ' ' + settings.rowCssPrefix + i.toString() + ' ' + settings.colCssPrefix + j.toString(); //setting the css className for respective seat.

        if ($.isArray(reservedSeat) && $.inArray(seatNo, reservedSeat) != -1) { // check if reserved seat or not to change the Css of reserved seat
          className += ' ' + settings.selectedSeatCss;
        }
        //adding the styled seat into an array for display. 
        str.push('<li class="' + className + '"' +
          'style="padding:6px;color:orange;top:' + (i * settings.seatHeight).toString() + 'px;left:' + (j * settings.seatWidth).toString() + 'px">' +
          '<a title="' + seatNo + '">' + seatNo + '</a>' +
          '</li>');
      }
    }
    $('#place').html(str.join(''));
  };

  var bookedSeats = [1, 2, 60];  // variable declared for already booked seat to display in red colour.
  var bronzeSeats = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29
  ,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45]; // SeatNo which falls in Bronze category.
  var goldSeats = [61,62,63,64,65,66,67,68,69,70,71,72,73,74,75]; // SeatNo which falls in Gold category.
  var silverSeats = [46,47,48,49,50,51,52,53,54,55,56,57,58,59,60]; // SeatNo which falls in Silver category.
  var cornerSeats = [1,15,16,30,31,45,46,75]; // SeatNo which falls in corner seats.
  init(bookedSeats,silverSeats,goldSeats); // Call init function parameter passed is bookedSeats and respective category of seats.
  var bookingSeats = []; //Array to store the booking seats by the user.
  var count = 0; //no. of seats selected by user.
  var flag = true; //to check if right/ left corner seat. true => right and false => left.
  var ticketClass = sessionStorage.getItem('ticketClass'); //to store ticketClass passed from the booking page.
  var numberOfTickets = sessionStorage.getItem('numberOfTickets');//to store no. of tickets sent from booking page.
  var error = document.getElementById('error');//get element to display error message.

  $('.' + settings.seatCss).click(function () {
    var currentSeat = $(this);
    // check if category choosed by used is GOLD class and show error message if user choose another category.
    if (ticketClass === "Gold" && goldSeats.indexOf(parseInt(currentSeat.attr('textContent'))) == -1)
    {
      error.innerHTML = "Only Gold Class Tickets to be selected";
      return false;
    }
    // check if category choosed by used is SILVER class and show error message if user choose another category.
    if (ticketClass === "Silver" && silverSeats.indexOf(parseInt(currentSeat.attr('textContent'))) == -1)
    {
      error.innerHTML = "Only Silver Class Tickets to be selected";
      return false;
    }
    // check if category choosed by used is BRONZE class and show error message if user choose another category.
    if (ticketClass === "Bronze" && bronzeSeats.indexOf(parseInt(currentSeat.attr('textContent'))) == -1)
    {
        error.innerHTML = "Only Bronze Class Tickets to be selected";
        return false;
    }
    
    // check if user clicks on already booked seats and shows an alert message.
    if ($(this).hasClass(settings.selectedSeatCss))
    {
          error.innerHTML = "";
          alert('This seat is already reserved');
    }
    else
    {
          error.innerHTML = ""; // clears the error message.
          // check if no. of seats selected is less than equals to total no. of seats to be selected and check if seat is already selected by user.
          if (count < numberOfTickets || bookingSeats.indexOf(currentSeat.attr('textContent')) != -1)
          { 
                var adjacentSeat_next = (parseInt(currentSeat.attr('textContent')) + 1).toString(); //find seatNo of next the seat beside the current seected seat.
                var adjacentSeat_prev = (parseInt(currentSeat.attr('textContent')) - 1).toString(); //find seatNo of previous the seat beside the current seected seat.

                //check if current selected seat is already selected or not.
                if (bookingSeats.indexOf(currentSeat.attr('textContent')) != -1)
                {
                  // check if adjacent seats already booked or not.
                  if ((bookingSeats.indexOf(adjacentSeat_next) == -1) || (bookingSeats.indexOf(adjacentSeat_prev) == -1))
                  {
                    //check if user unselects corner seat when he already has a selected adjacent seat.
                    if (cornerSeats.indexOf(parseInt(currentSeat.attr('textContent'))) != -1 
                      && 
                      (bookingSeats.indexOf(adjacentSeat_next) != -1 || bookingSeats.indexOf(adjacentSeat_prev) != -1)){
                      alert('Corner Seat cannot be left empty');
                      return true;
                    }
                    else // allow unselecting the selected seat and decrement the count of selected seat by user.
                    {
                    count = count - 1;
                    bookingSeats.splice(bookingSeats.indexOf(currentSeat.attr('textContent')),1);
                    }
                  } 
                  else //If adjacent seat is left empty alert user.
                  {
                    alert('Adjacent Seat cannot be left empty');
                    return true;
                  }
                }
                

                $(this).toggleClass(settings.selectingSeatCss); // select/unselect seat.

                // loop through all the selected seats based on stylesheet class.
                $.each($('#place li.' + settings.selectingSeatCss + ' a'), function (index, value) {
                item = $(this).attr('title'); // current selected seat.
                flag =true;
                // Validating the corner seats to prevent it from keeping it vacant.
                if (bookingSeats.indexOf(item) == -1) 
                {
                     switch(item) 
                     {
                        case '2' : validateCorners(item , true, currentSeat);
                                   break; 
                        case '14' : validateCorners(item , false, currentSeat);
                                   break; 
                        case '17' : validateCorners(item , true, currentSeat);
                                   break; 
                        case '29' : validateCorners(item , false, currentSeat);
                                   break; 
                        case '32' : validateCorners(item , true, currentSeat);
                                   break; 
                        case '44' : validateCorners(item , false, currentSeat);
                                   break; 
                        case '47' : validateCorners(item , true, currentSeat);
                                   break; 
                        case '59' : validateCorners(item , false, currentSeat);
                                   break; 
                        case '60' : validateCorners(item , true, currentSeat);
                                   break; 
                        case '74' : validateCorners(item , false, currentSeat);
                                   break;  
                     }

                      if (flag ==true)
                      {          
                        // check if its user first selection of seat thus push it in the array.     
                        if (count == 0)
                        {
                            bookingSeats.push(item); // adding the seat into array.
                            count=count+1; //increment counter for no of seats selected by user.
                        }
                        else // if selection of seat is not first.
                        {
                             var adjacentSeat_next = (parseInt(currentSeat.attr('textContent')) + 1).toString(); //next adjacent seat to current selected seat.
                             var adjacentSeat_prev = (parseInt(currentSeat.attr('textContent')) - 1).toString(); //previous adjacent seat to current selected seat.
                             if (bookingSeats.indexOf(adjacentSeat_prev) == -1 && bookingSeats.indexOf(adjacentSeat_next) == -1  && count >= 1) // check if user doesnot selects adjacent seat.
                             {
                               currentSeat.toggleClass(settings.selectingSeatCss); 
                               alert('Adjacent Seats cannot be left empty');
                             }
                             else //if he does select adjacent seat
                             {
                              bookingSeats.push(item); // add to  booking seat array.
                              count=count+1; //increment no. of selection made .
                             }
                        }
                      }
                }
              }); 
          }
    }
  });


  // function to check whether the corner seats are not kept empty/vacant during selection.
  function validateCorners(item , type , currentSeat){
  if (type)
    var item = (parseInt(item) - 1).toString();
  else
    var item = (parseInt(item) + 1).toString();

  // check if current selected seat is already booked or can be allowed to book.
  if (bookingSeats.indexOf(item) == -1 && bookedSeats.indexOf(parseInt(item)) == -1){
   currentSeat.toggleClass(settings.selectingSeatCss); // toggle classes inorder to select/ unselect seat.
   alert('Seat '+item+' cannot be left Empty');
   flag =false;
  }
  }

  // function to display total no of seats selected by the user.
  $('#book').click(function () {
    var str = [], item;
    //loop through all the selected seats and pushing it in an array the seat no for displaying.
    $.each($('#place li.' + settings.selectingSeatCss + ' a'), function (index, value) {
        item = $(this).attr('title');                   
        str.push(item);                   
    });
    // check if user has made all the selection of the tickets or left with selection and display alert accordingly.
    if (str.length < numberOfTickets)
      alert("You have seat selection pending");
    else
      alert("You have successfully booked seat no: "+str.join(' , '));
    });
  });
